package jv.oop.interfaces.and.abstraction.exercise.multiple.implementation;

public interface Identifiable {
	String getId();
}
