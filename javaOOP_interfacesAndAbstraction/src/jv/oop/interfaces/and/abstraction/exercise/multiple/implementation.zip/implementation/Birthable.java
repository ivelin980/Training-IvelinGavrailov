package jv.oop.interfaces.and.abstraction.exercise.multiple.implementation;

public interface Birthable {
	String getBirthDate();
}
