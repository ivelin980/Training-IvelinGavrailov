package jv.oop.interfaces.and.abstraction.exercise.multiple.implementation;

public interface Person {
	String getName();

	int getAge();
}
