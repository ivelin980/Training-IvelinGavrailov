package listutilities;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		List<String> strings = new ArrayList<>();
		List<Integer> integers = new ArrayList<>();
		Collections.addAll(integers, 100,20,35,52);
		System.out.println(ListUtils.getMax(integers));
		Collections.addAll(strings, "abc","abcd","bda");
		System.out.println(ListUtils.getMax(strings));
		ListUtils.sort(integers);
		System.out.println();
	}
}
