package genericcountmethodstrings;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		List<Box<String>> boxes = new ArrayList<>();
		int inputNumber = Integer.parseInt(scan.nextLine());
		for (int i = 0; i < inputNumber; i++) {
			Box<String> box = new Box<>(scan.nextLine());
			boxes.add(box);
		}
		String element = scan.nextLine();
		int count = 0;
		for (Box<String> box : boxes) {
			if(box.getInput().compareTo(element)>0) {
				count++;
			}
		}
		System.out.println(count);
		scan.close();
	}
}
